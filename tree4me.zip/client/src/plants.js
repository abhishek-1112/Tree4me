const plants=[
    {
        type:"Neem",
        templeteimage: "https://res.cloudinary.com/sidd293/image/upload/v1677601127/TREE4ME/WhatsApp_Image_2023-02-28_at_07.29.26_qb8mwj.jpg",
        description : "Neem has endless medicinal properties and that's what makes it popular in India. It is used to control pests and deal with pox viruses. Neem is a major ingredient in soaps and shampoos and is healthy for our skin.",
        cost :  345,
    },

    {
        type:"Mango",
        templeteimage : "https://res.cloudinary.com/sidd293/image/upload/v1677601128/TREE4ME/WhatsApp_Image_2023-02-28_at_07.29.27_1_kvllcu.jpg",
        description:"Everybody's favourite fruit, who doesn't love mangoes beside mango, the mango tree poses medicinal properties as well, various parts of plant are used as a dentrifice, stomachic, vermifuge, tonic, laxative and diurectic and countless more advantages.",
        cost: 640,
    },
    {
        type:"Apple",
        templeteimage:"https://res.cloudinary.com/sidd293/image/upload/v1677601128/TREE4ME/WhatsApp_Image_2023-02-28_at_07.29.26_1_t0teps.jpg",
        description:"The friut that never goes out of season, the medicinal advantages of apple are so that it even keeps the doctor away that alone the fruit, the tree is widelyl used in oriental medicines, the roots of the apple tree are decoction, analgesic, treatment for tuberculosis",
        cost: 545,
    },
    {
        type:"Guava",
        templeteimage:"https://res.cloudinary.com/sidd293/image/upload/v1677601125/TREE4ME/WhatsApp_Image_2023-02-28_at_07.29.28_h26unu.jpg",
        description:"It is one of the most important fruits of India, the summer time treat filled with fibre and vitamin c, the unique taste of guava is accompanied by enormous mirco-nutrients not only the fruit but the guava leaves are full of benefits as well.",
        cost: 545,
    },
    {
        type:"Coconut",
        templeteimage:"https://m.media-amazon.com/images/I/61BtR31MjNL._SY300_SX300_QL70_FMwebp_.jpg",
        description:"NO one beats the heat of summer like a good old coconit water, we indians are fan and fond of, wether its that tasty insides it all comes from the tree that posses one of the most advantages it is easy to grow and holds onto the soil",
        cost: 540,
    },
    {
        type:"Banyan",
        templeteimage:"https://res.cloudinary.com/sidd293/image/upload/v1677601334/TREE4ME/360_F_212698839_bWzVsqRaXsi5kfowZdjsaxKD2hg2g3w7_ufkrg1.jpg",
        description:"The king of trees, our national tree, advantages to us maybe not so, but to the environment enormous. Home to birds, insects, and many wildlife creatures, with the cherry on top that it produces the highest amount of oxygen in comparison to any tree.",
        cost: 540,
    }
]
export  {plants};
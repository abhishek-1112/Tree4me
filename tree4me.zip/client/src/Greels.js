import React from 'react'
import Video from './Video'

export default function Greels() {
  return (
    <div style = {{"margin-inline":"auto","width":"40%","height" : "100vh"}} className = "greels">
<Video url = {"https://res.cloudinary.com/dqbs3ezg9/video/upload/v1677655341/Beautiful_tree_Plantation_Natural_Tree_Funny_Moments_Tree_Plantation_Alamin_Dipu_Vlogs_yltocy.mp4"}></Video>
<Video url = {"https://res.cloudinary.com/dqbs3ezg9/video/upload/v1677655353/Donate_to_our_Tree4me_Project_myxzlw.mp4"}></Video>
<Video url = {"https://res.cloudinary.com/dqbs3ezg9/video/upload/v1677655354/tobacco-farming-pay-attention-to-irrigation-satisfying-short-1920-ytshorts.savetube.me_emjp6q.mp4"}></Video>
<Video url = {"https://res.cloudinary.com/dqbs3ezg9/video/upload/v1677656062/tp2_e61yb2.mp4"}></Video>

    </div>
  )
}
